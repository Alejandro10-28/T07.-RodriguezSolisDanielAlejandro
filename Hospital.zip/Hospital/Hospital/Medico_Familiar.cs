﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    //Se deja como subclase de la clase medico
    class Medico_Familiar:Medico
    {
        //Aqui no se ponen atributos ya que tiene los de la clase Medico.
    }
}
