﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    //Se deja como subclase de la clase persona
    class Cirujano:Persona
    {
        //Se encapsula
        public string Area { get; set; }

    }
}
