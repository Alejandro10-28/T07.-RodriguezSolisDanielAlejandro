﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    class Principal
    {
        //Se crea el metdoo bienvenida para el usuario.
        public void Bienvenida()
        {
            Console.WriteLine("=======Bienvenido al hospital 32==========");

        }
    }
}
